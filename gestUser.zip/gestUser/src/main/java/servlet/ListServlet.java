package servlet;

import java.io.IOException;
import java.util.ArrayList;

import dao.UtilisateurDao;
import gestUser.Utilisateur;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 

@WebServlet({"/list" , ""})
public class ListServlet extends HttpServlet{
	
	private static final String VUE_LIST_UTILISATEUR = "/WEB-INF/listerUtilisateur.jsp";
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(VUE_LIST_UTILISATEUR);
		
		ArrayList<Utilisateur> listUtilisateurs = UtilisateurDao.lister();
		request.setAttribute("utilisateurs", listUtilisateurs);
		dispatcher.forward(request, response);
		
	}

}
