package dao;

import java.util.ArrayList;
import java.util.Iterator;

import gestUser.Utilisateur;

public class UtilisateurDao {
	
	private final static ArrayList<Utilisateur> utilisateurs = new ArrayList<Utilisateur>();
	
	private static int LastId=0;
	
	static
	{
		utilisateurs.add(new Utilisateur(1,"Dan","Steve","Admin","Passer"));
		utilisateurs.add(new Utilisateur(2,"Syriack","Falvien","Admin","Passer"));
		utilisateurs.add(new Utilisateur(3,"Jean","Aime","Membre","Passer"));
	}
	
	public static ArrayList<Utilisateur> lister(){
		
		return utilisateurs;
	}
	
	public static void ajouter(Utilisateur utilisateur) {
		
		LastId ++;
		utilisateur.setId(LastId);
		utilisateurs.add(utilisateur);
	}
	
	public static boolean supprimer(int id) {
		
		for (Utilisateur utilisateur : utilisateurs) {
			
			if (utilisateur.getId() == id) {
				utilisateurs.remove(utilisateur);
				return true;
			}
			
		}
		return false;
	}
	
	public static Utilisateur get(int id) {
		for (Utilisateur utilisateur : utilisateurs) {
			if (utilisateur.getId() == id) {
				return utilisateur;
			}
			
		}
		return null;
	}

	public static boolean modifier(Utilisateur user) {
		// TODO Auto-generated method stub
		 for (Utilisateur utilisateur : utilisateurs) 
		 {
			if (utilisateur.getId() == user.getId()) {
				utilisateur.setNom(user.getNom());
				utilisateur.setPrenom(user.getPrenom());
				utilisateur.setLogin(user.getLogin());
				utilisateur.setPassword(user.getPassword());
				
				return true;
			} 
		 }
		return false;
	}

}
